### dllmain.cpp & PacketHandler.h

This is the custom version of the V4 Kangaroo crack that I made to dump the stuffs.

**The code is extremely dirty, it's just there as a POC**

If you want, you can dump the files yourself using this. (don't forget to change the server ws url, and define HOOKK)

### mitm_server.py

For Vape Lite, I decided to do a MITM since it didn't check the certs.

Again, the code is dirty, it's just a POC.
